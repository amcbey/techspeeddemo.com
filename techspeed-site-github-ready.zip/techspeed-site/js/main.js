(function () {
  // Year
  const y = document.getElementById("year");
  if (y) y.textContent = new Date().getFullYear();

  // Mobile nav toggle
  const btn = document.getElementById("menuBtn");
  const panel = document.getElementById("mobilePanel");
  if (btn && panel) {
    btn.addEventListener("click", () => {
      const open = panel.style.display === "block";
      panel.style.display = open ? "none" : "block";
      btn.setAttribute("aria-expanded", String(!open));
    });
  }

  // Scroll reveal
  const revealEls = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window && revealEls.length) {
    const io = new IntersectionObserver((entries) => {
      for (const e of entries) {
        if (e.isIntersecting) {
          e.target.classList.add("in");
          io.unobserve(e.target);
        }
      }
    }, { threshold: 0.12 });
    revealEls.forEach(el => io.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add("in"));
  }

  // Pricing toggle (monthly/annual)
  const sw = document.querySelector("[data-pricing-switch]");
  if (sw) {
    const prices = document.querySelectorAll("[data-price-month],[data-price-year]");
    const label = document.querySelector("[data-pricing-label]");
    const setMode = (on) => {
      sw.dataset.on = String(on);
      prices.forEach(p => {
        const m = p.getAttribute("data-price-month");
        const yr = p.getAttribute("data-price-year");
        p.textContent = on ? yr : m;
      });
      if (label) label.textContent = on ? "Annual (save)" : "Monthly";
    };
    sw.addEventListener("click", () => {
      const on = sw.dataset.on === "true";
      setMode(!on);
    });
    setMode(false);
  }

  // Resources search/filter
  const search = document.querySelector("[data-resource-search]");
  const chips = document.querySelectorAll("[data-tag]");
  const cards = document.querySelectorAll("[data-resource-card]");
  let activeTag = "All";

  const applyFilter = () => {
    const q = (search?.value || "").trim().toLowerCase();
    cards.forEach(c => {
      const title = (c.getAttribute("data-title") || "").toLowerCase();
      const tag = c.getAttribute("data-tag") || "";
      const okTag = activeTag === "All" || tag === activeTag;
      const okQ = !q || title.includes(q);
      c.style.display = (okTag && okQ) ? "" : "none";
    });
  };

  if (search) search.addEventListener("input", applyFilter);
  chips.forEach(ch => {
    ch.addEventListener("click", () => {
      activeTag = ch.getAttribute("data-tag") || "All";
      chips.forEach(x => x.dataset.active = String(x === ch));
      applyFilter();
    });
  });
  if (chips.length) chips[0].dataset.active = "true";
  applyFilter();

  // Auth tabs (login/signup)
  const tabBtns = document.querySelectorAll("[data-tab]");
  const panels = document.querySelectorAll("[data-tab-panel]");
  if (tabBtns.length && panels.length) {
    const show = (name) => {
      tabBtns.forEach(b => b.setAttribute("aria-selected", String(b.dataset.tab === name)));
      panels.forEach(p => p.style.display = (p.dataset.tabPanel === name) ? "block" : "none");
    };
    tabBtns.forEach(b => b.addEventListener("click", () => show(b.dataset.tab)));
    show(tabBtns[0].dataset.tab);
  }

  // Template forms
  document.querySelectorAll("[data-template-form]").forEach(form => {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      alert("Template form: connect this to your backend, auth provider, or CRM.");
    });
  });
})();