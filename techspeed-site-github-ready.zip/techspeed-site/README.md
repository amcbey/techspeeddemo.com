# TechSpeed Website Template (GitHub-ready)

Static multi-page template (no build tools required).

## Pages
- Home: `index.html`
- About: `about.html`
- Pricing: `pricing.html`
- Resources: `resources.html`
- Contact: `contact.html`
- Client Portal: `login.html` (login + sign up template)

## Run locally
Option A: open `index.html` in a browser  
Option B (recommended): in this folder run:
`python3 -m http.server`
Then open http://localhost:8000

## Deploy to GitHub Pages
1. Create a GitHub repo and upload the contents of this folder to the repo root
2. GitHub repo → Settings → Pages
3. Source: Deploy from branch → Branch: main → Folder: /(root)
4. Visit the URL GitHub provides
